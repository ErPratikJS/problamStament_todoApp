import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {

  constructor(private http:HttpClient) { }

 /* public doRegistration(user)
  {
    return this.http.post("http://localhost:9091/register")
     this.http.post("http://localhost:8080/register",user).subscribe(data=> {status=true})
  }*/

  public getUser()
  {
    return this.http.get("http://localhost:9091/users");
  }

  public getAdmin()
  {
    return this.http.get("http://localhost:9091/todo/admins");
  }
  public postuser(user)
  {
    console.log(user);
    return this.http.post("http://localhost:9091/register",user);

  }
}
