import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationService } from '../user-registration.service';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  date:Date= new Date();
  @ViewChild('signup') user: NgForm;
  users:any;
  constructor(private route:Router,private http:HttpClient,private userRegistrationService:UserRegistrationService) { 
   
  }
  ngOnInit(): void {
    this.userRegistrationService.getUser()
      .subscribe( (data:any) => {
        this.users = data;
        console.log(this.users);
      });
     
  }
 // valid = this.terms.nativeElement.checked;
  
  onSignUp(form) {
    console.log(form.access);
    const cnt:any =this.users.length;
    let obj ={email:form.email,firstName:form.firstName,lastName:form.lastName,gender:form.gender,bdate:form.birthdate,password:form.password,access:form.access}
    
   
   
   this.userRegistrationService.postuser(obj).subscribe((data:any)=> {
    console.log(data);
   
});





    /*    const ndte:number= new Date(form.value.birthdate).getFullYear();
    console.log(ndte);
    const diff:number= new Date().getFullYear() - ndte;
    alert("age : "+diff)
    if(diff>=18)
    {
      alert("Successfull !!!");
    this.user.reset();
    }
    else
    {
      alert("Age is below 18");
    }
  */
 
  

  }

  
}

/**import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {


  @ViewChild('signup') user: NgForm;
  
  constructor(private route:Router) { 
  }
  date: Date = new Date();  
   
  
  
  ngOnInit() {
  }
  
 // valid = this.terms.nativeElement.checked;
  
  onSignUp(form) {
    console.log(form);
    
    const diff:number= new Date().getFullYear() - new Date(form.value.birthdate).getFullYear();
    alert("age : "+diff)
    if(diff>=18)
    {
      alert("Successfull !!!");
    console.log(form);
    let arr: any[]=JSON.parse(localStorage.getItem("userToDo"));
    if(arr==null)
    {
      arr=[];
    }
    arr.push(form);
    localStorage.setItem("userToDo",JSON.stringify(arr));
    this.user.reset();
    }
    else
    {
      alert("Age is below 18");
    }
    
  }

  
}
 */