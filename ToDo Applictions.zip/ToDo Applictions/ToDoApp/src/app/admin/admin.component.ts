import { Component, OnInit } from '@angular/core';
import { UserRegistrationService } from '../user-registration.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  user:any;

  constructor(private userRegistrationService:UserRegistrationService) { 
   
  }
  ngOnInit(): void {
    this.userRegistrationService.getUser()
      .subscribe( (data:any) => {
        this.user = data;
        console.log(this.user);
      });
     
  }
 
  access(i){
   // this.user[i].access=!this.user[i].access;
 console.log("Admin")


  }
}
